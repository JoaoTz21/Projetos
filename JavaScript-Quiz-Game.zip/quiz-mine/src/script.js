// PARTE 1: Lista de perguntas e respostas //"2011","2010","2009","2008"
perguntas = [
  {
    pergunta: "Em que ano Minecraft foi lançado?",
    respostas: [
      { opcao: "2009", correto: true },
      { opcao: "2011", correto: false },
      { opcao: "2010", correto: false },
      { opcao: "2008", correto: false }
    ]
  },
  {
    pergunta: "Qual é o nome do criador do Minecraft?",
    respostas: [
      { opcao: "Markus Persson", correto: true },
      { opcao: "Jens Bergensten", correto: false },
      { opcao: "Notch", correto: true },
      { opcao: "Elon Musk", correto: false }
    ]
  },
  {
    pergunta:
      "Qual mob é conhecido por explodir quando se aproxima do jogador?",
    respostas: [
      { opcao: "Creeper", correto: true },
      { opcao: "Zumbi", correto: false },
      { opcao: "Esqueleto", correto: false },
      { opcao: "Enderman", correto: false }
    ]
  },
  {
    pergunta: "Qual desses materiais é o mais resistente no jogo?",
    respostas: [
      { opcao: "Bedrock", correto: true },
      { opcao: "Obsidian", correto: false },
      { opcao: "Diamante", correto: false },
      { opcao: "Ferro", correto: false }
    ]
  },
  {
    pergunta: "Qual é a dimensão alternativa ao Overworld em Minecraft?",
    respostas: [
      { opcao: "Nether", correto: true },
      { opcao: "End", correto: true },
      { opcao: "Aether", correto: false },
      { opcao: "Void", correto: false }
    ]
  },
  {
    pergunta: "Qual animal dá couro quando morto?",
    respostas: [
      { opcao: "Vaca", correto: true },
      { opcao: "Galinha", correto: false },
      { opcao: "Porco", correto: false },
      { opcao: "Ovelha", correto: false }
    ]
  },
  {
    pergunta: "Qual item é necessário para acender um portal do Nether?",
    respostas: [
      { opcao: "Isqueiro", correto: true },
      { opcao: "Tocha", correto: false },
      { opcao: "Pedra vermelha", correto: false },
      { opcao: "Lava", correto: false }
    ]
  },
  {
    pergunta: "Qual boss é encontrado no End?",
    respostas: [
      { opcao: "Ender Dragon", correto: true },
      { opcao: "Wither", correto: false },
      { opcao: "Ghast", correto: false },
      { opcao: "Blaze", correto: false }
    ]
  },
  {
    pergunta: "Qual item NÃO pode ser obtido minerando?",
    respostas: [
      { opcao: "Madeira", correto: true },
      { opcao: "Carvão", correto: false },
      { opcao: "Ferro", correto: false },
      { opcao: "Ouro", correto: false }
    ]
  },
  {
    pergunta:
      "Quantos blocos um sinal de redstone pode percorrer sem repetidor?",
    respostas: [
      { opcao: "15", correto: true },
      { opcao: "10", correto: false },
      { opcao: "20", correto: false },
      { opcao: "5", correto: false }
    ]
  },
  {
    pergunta: "Qual é a função principal de um 'Hopper'?",
    respostas: [
      { opcao: "Transportar itens", correto: true },
      { opcao: "Gerar mobs", correto: false },
      { opcao: "Teleportar jogadores", correto: false },
      { opcao: "Armazenar XP", correto: false }
    ]
  },
  {
    pergunta: "Qual planta é usada para fazer pão?",
    respostas: [
      { opcao: "Trigo", correto: true },
      { opcao: "Cenoura", correto: false },
      { opcao: "Batata", correto: false },
      { opcao: "Beterraba", correto: false }
    ]
  },
  {
    pergunta: "Qual mob dropa 'Ender Pearls'?",
    respostas: [
      { opcao: "Enderman", correto: true },
      { opcao: "Blaze", correto: false },
      { opcao: "Ghast", correto: false },
      { opcao: "Slime", correto: false }
    ]
  },
  {
    pergunta: "Qual item é usado para criar um 'Wither'?",
    respostas: [
      { opcao: "Cabeça de Wither Skeleton", correto: true },
      { opcao: "Cabeça de Esqueleto", correto: false },
      { opcao: "Cabeça de Creeper", correto: false },
      { opcao: "Cabeça de Zumbi", correto: false }
    ]
  },
  {
    pergunta: "Qual bloco emite mais luz no jogo?",
    respostas: [
      { opcao: "Sea Lantern", correto: true },
      { opcao: "Tocha", correto: false },
      { opcao: "Lava", correto: false },
      { opcao: "Glowstone", correto: true }
    ]
  },
  {
    pergunta: "Qual é a profundidade máxima para encontrar diamantes?",
    respostas: [
      { opcao: "Y=16", correto: false },
      { opcao: "Y=12", correto: true },
      { opcao: "Y=20", correto: false },
      { opcao: "Y=5", correto: false }
    ]
  },
  {
    pergunta: "Qual item é necessário para criar um 'Enchanting Table'?",
    respostas: [
      { opcao: "Diamante", correto: true },
      { opcao: "Ouro", correto: false },
      { opcao: "Esmeralda", correto: false },
      { opcao: "Ferro", correto: false }
    ]
  },
  {
    pergunta: "Qual mob NÃO aparece no Nether?",
    respostas: [
      { opcao: "Zumbi", correto: false },
      { opcao: "Blaze", correto: false },
      { opcao: "Ghast", correto: false },
      { opcao: "Peixe", correto: true }
    ]
  },
  {
    pergunta: "Qual é a cor da lã mais rara encontrada naturalmente?",
    respostas: [
      { opcao: "Rosa", correto: true },
      { opcao: "Verde", correto: false },
      { opcao: "Azul", correto: false },
      { opcao: "Marrom", correto: false }
    ]
  },
  {
    pergunta: "Qual item é usado para criar um 'Beacon'?",
    respostas: [
      { opcao: "Estrela do Nether", correto: true },
      { opcao: "Diamante", correto: false },
      { opcao: "Esmeralda", correto: false },
      { opcao: "Ouro", correto: false }
    ]
  },
  {
    pergunta: "Qual é o efeito de comer 'Poisonous Potato'?",
    respostas: [
      { opcao: "Envenenamento", correto: true },
      { opcao: "Fome", correto: false },
      { opcao: "Náusea", correto: false },
      { opcao: "Nenhum efeito", correto: false }
    ]
  }
];

// PARTE 2: Pegando os elementos do HTML
const perguntaElemento = document.querySelector(".pergunta");
const respostasElemento = document.querySelector(".respostas");
const progressoElemento = document.querySelector(".progresso");
const textoFinal = document.querySelector(".fim span");
const conteudo = document.querySelector(".conteudo");
const conteudoFinal = document.querySelector(".fim");

// PARTE 3: Variáveis para controle do jogo
let indiceAtual = 0; // Índice da pergunta atual
let acertos = 0; // Contador de acertos

// PARTE 4: Função para carregar uma nova pergunta
function carregarPergunta() {
  progressoElemento.innerHTML = `${indiceAtual + 1}/${perguntas.length}`; // Atualiza o progresso
  const perguntaAtual = perguntas[indiceAtual]; // Pega a pergunta atual
  perguntaElemento.innerHTML = perguntaAtual.pergunta; // Exibe a pergunta

  respostasElemento.innerHTML = ""; // Limpa as respostas anteriores

  // Percorre todas as respostas da pergunta atual
  for (let i = 0; i < perguntaAtual.respostas.length; i++) {
    // Pega a resposta atual com base no índice 'i'
    const resposta = perguntaAtual.respostas[i];
    // Cria um novo elemento 'button' (botão)
    const botao = document.createElement("button");
    // Adiciona a classe CSS 'botao-resposta' ao botão para estilizar
    botao.classList.add("botao-resposta");
    // Define o texto do botão com a opção de resposta (resposta.opcao)
    botao.innerText = resposta.opcao;
    // Adiciona um evento de clique no botão
    botao.onclick = function () {
      // Se a resposta for correta (resposta.correto === true), incrementa o número de acertos
      if (resposta.correto) {
        acertos++; // Incrementa o contador de acertos
      }

      // Avança para a próxima pergunta
      indiceAtual++;

      // Se ainda houver perguntas, carrega a próxima pergunta
      if (indiceAtual < perguntas.length) {
        carregarPergunta(); // Carrega a próxima pergunta
      } else {
        // Se não houver mais perguntas, finaliza o jogo
        finalizarJogo();
      }
    };

    // Adiciona o botão de resposta à tela, dentro do elemento 'respostasElemento'
    respostasElemento.appendChild(botao);
  }
}

// PARTE 5: Função para mostrar a tela final
function finalizarJogo() {
  textoFinal.innerHTML = `Você acertou ${acertos} de ${perguntas.length}`; // Exibe o resultado
  conteudo.style.display = "none"; // Esconde as perguntas
  conteudoFinal.style.display = "flex"; // Mostra a tela final
}

// PARTE 6: Iniciando o jogo pela primeira vez
carregarPergunta();
