idade = prompt("Quantos anos você tem?");
if (idade < 18) {
  alert("Você não pode jogar!");
}
//alert("Vamos começar!")
if (idade >= 18) {
  escolhajogador = prompt("Escolha! 1-pedra, 2-papel ou 3-tesoura");
  escolhacomputador = Math.floor(Math.random() * 3) + 1;

  // Jogador = Pedra, Computador = Pedra --> Empate
  // Jogador = Papel, Computador = Papel --> Empate
  // Jogador = Tesoura, Computador = Tesoura --> Empate

  if (escolhajogador == escolhacomputador) {
    alert("Deu empate!");
  }

  // Jogador = Tesoura, Computador = Pedra --> Computador Ganha
  // Jogador = Tesoura, Computador = Papel --> Jogador Ganha

  if (escolhajogador == 1) {
    if (escolhacomputador == 3) {
      alert("Você ganhou, computador escolheu tesoura!");
    }
    if (escolhacomputador == 2) {
      alert("O computador ganhou, escolheu papel!");
    }
    // Jogador = Tesoura, Computador = Papel --> Jogador Ganha
    // 1-pedra 2 papel 3 tesoura
  }
  if (escolhajogador == 2) {
    if (escolhacomputador == 1) {
      alert("Você ganhou, computador escolheu pedra!!");
    }
    if (escolhacomputador == 3) {
      alert("O computador ganhou, escolheu tesoura!");
    }
  }
  // Jogador = Pedra, Computador = papel --> Computador Ganha
  // Jogador = Pedra, Computador = Tesoura --> Jogador Ganha
  if (escolhajogador == 3) {
    if (escolhacomputador == 2) {
      alert("Você ganhou, computador escolheu papel!");
    }
    if (escolhacomputador == 1) alert("O computador ganhou, escolheu pedra!");
  }

  // Jogador = Papel, Computador = Pedra --> Jogador Ganha
  // Jogador = Papel, Computador = Tesoura --> Computador Ganha

  alert("A escolha do computador foi:" + escolhacomputador);
}
