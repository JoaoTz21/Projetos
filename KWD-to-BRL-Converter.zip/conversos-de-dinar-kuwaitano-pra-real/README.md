# Conversos de Dinar Kuwaitano pra Real

A Pen created on CodePen.

Original URL: [https://codepen.io/JoaoTz/pen/pvoGjLE](https://codepen.io/JoaoTz/pen/pvoGjLE).

