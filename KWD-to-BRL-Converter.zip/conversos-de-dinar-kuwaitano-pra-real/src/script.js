valorkwd = prompt("Digite o Valor em Dinar Kuwaitano")
dinar = 18.36 
alert("O valor convertido em R$ é: " + valorkwd * dinar)