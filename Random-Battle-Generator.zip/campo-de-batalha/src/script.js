personagem = ["", "", ""]

viloes = ["", "", ""]

forçapersonagem = 0

forçaviloes = 0
alert("Bem vindo ao Campo de batalha!!")
for(let i=0; i<3; i++){
  escolhapersonagem = prompt("Digite os nomes dos Heróis do seu time: " + (i + 1) + ":")
  personagem[i] = escolhapersonagem
  //Calcular a força dos personagens
  //maneira menos avançada: forçapersonagem = forçapersonagem + Math.floor(Math.random() * 10) + 1
  forçapersonagem += Math.floor(Math.random() * 10) + 1
   
}                      
alert("O time dos heróis tem:" + personagem)
for(let i=0; i<3; i++){
  
  indicealeatorio = Math.floor(Math.random() * 6)
  possiveisviloes = ["Kurzak","Khorvaxx","Mortak","Salkarath","Gromm","Kael"]
  viloes[i] = possiveisviloes[indicealeatorio]
    forçaviloes += Math.floor(Math.random() * 10) + 1
  }

alert("O time dos vilões tem:" + viloes)

if (forçapersonagem > forçaviloes){
  alert("O time dos heróis ganhou! Sua força: " + forçapersonagem + "! Força do vilões: " + forçaviloes + "!")
}
else{ 
  if(forçapersonagem < forçaviloes){
    alert("O time dos vilões ganhou! A força dos vilões: " + forçaviloes + "! Sua força: " + forçapersonagem + "!")}
  else{
    alert("Deu empate! os dois times são muito fortes.")}
  
  }
 